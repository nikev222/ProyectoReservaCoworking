package servlets;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// Servlet para mostrar la lista de reservas
@WebServlet("/ListaReservasServlet")
public class ListaReservasServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * Metodo que maneja las peticiones GET para mostrar las reservas
     * Se obtiene la lista de reservas y se envia a la pagina JSP
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Obtener la lista de reservas desde el servlet principal
        List<Map<String, String>> reservas = ReservaServlet.getReservas();
        
        // Pasar la lista de reservas como atributo para la vista
        request.setAttribute("reservas", reservas);
        
        // Redireccionar a la pagina JSP donde se mostraran las reservas
        request.getRequestDispatcher("reservas.jsp").forward(request, response);
    }
}