package servlets;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet para eliminar una reserva de la lista de reservas almacenadas en memoria.
 * Recibe un parametro con el ID de la reserva a eliminar y la borra si existe.
 */
@WebServlet("/EliminarReservaServlet")
public class EliminarReservaServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * Maneja las solicitudes GET para eliminar una reserva.
     * Obtiene el ID de la reserva desde la peticion, verifica si es valido y la elimina de la lista.
     * Luego, muestra una alerta y redirige a la lista de reservas.
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String idParam = request.getParameter("id");
        boolean eliminado = false;

        if (idParam != null) {
            try {
                int id = Integer.parseInt(idParam);
                List<Map<String, String>> reservas = ReservaServlet.getReservas();
                
                // Verifica si el ID es valido y elimina la reserva
                if (id >= 0 && id < reservas.size()) {
                    reservas.remove(id);
                    eliminado = true;
                }
            } catch (NumberFormatException e) {
                e.printStackTrace(); // Imprime el error en consola si el ID no es un numero valido
            }
        }

        // Genera una alerta en JavaScript y redirige a la lista de reservas
        response.setContentType("text/html");
        response.getWriter().println("<script>alert('La reserva se elimino correctamente.'); window.location='ListaReservasServlet';</script>");
    }
}
