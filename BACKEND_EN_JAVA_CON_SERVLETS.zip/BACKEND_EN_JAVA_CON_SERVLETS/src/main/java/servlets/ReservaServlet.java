package servlets;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet para gestionar las reservas de espacios.
 * Permite recibir datos de un formulario, validarlos y almacenarlos en una lista en memoria.
 */
@WebServlet("/ReservaServlet")
public class ReservaServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    /** Lista estatica en memoria que almacena las reservas */
    private static final List<Map<String, String>> reservas = new ArrayList<>();

    /**
     * Maneja las solicitudes POST para registrar una nueva reserva.
     * Recibe los datos del formulario, los valida y los almacena en la lista.
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String nombre = request.getParameter("nombre");
        String fecha = request.getParameter("fecha");
        String espacio = request.getParameter("espacio");
        String duracionStr = request.getParameter("duracion");

        // Validaciones de campos obligatorios
        if (nombre == null || nombre.trim().isEmpty() ||
            fecha == null || fecha.trim().isEmpty() ||
            espacio == null || espacio.trim().isEmpty() ||
            duracionStr == null || duracionStr.trim().isEmpty()) {
            response.getWriter().write("<script>alert('Todos los campos son obligatorios.');window.history.back();</script>");
            return;
        }
        
        // Validar formato de fecha
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        sdf.setLenient(false);
        Date fechaReserva;
        try {
            fechaReserva = sdf.parse(fecha);
            if (fechaReserva.before(new Date())) {
                response.getWriter().write("<script>alert('La fecha no puede ser anterior a hoy.');window.history.back();</script>");
                return;
            }
        } catch (ParseException e) {
            response.getWriter().write("<script>alert('Formato de fecha invalido.');window.history.back();</script>");
            return;
        }
        
        // Validar duracion
        int duracion;
        try {
            duracion = Integer.parseInt(duracionStr);
            if (duracion <= 0) {
                response.getWriter().write("<script>alert('La duracion debe ser un numero positivo.');window.history.back();</script>");
                return;
            }
        } catch (NumberFormatException e) {
            response.getWriter().write("<script>alert('La duracion debe ser un numero valido.');window.history.back();</script>");
            return;
        }

        // Crear y agregar la reserva a la lista
        Map<String, String> reserva = new HashMap<>();
        reserva.put("nombre", nombre);
        reserva.put("fecha", fecha);
        reserva.put("espacio", espacio);
        reserva.put("duracion", duracionStr);
        reservas.add(reserva);
        
        // Confirmacion de reserva exitosa
        response.getWriter().write("<script>alert('Reserva realizada correctamente.');window.location.href='reservas.jsp';</script>");
    }
    
    /**
     * Metodo para obtener la lista de reservas almacenadas en memoria.
     */
    public static List<Map<String, String>> getReservas() {
        return reservas;
    }
}
